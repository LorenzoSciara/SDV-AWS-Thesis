---
title: Architecture
weight: 60
---

Overview of hawkBit modules and used 3rd party technology:
![](../images/architecture/architecture.png)