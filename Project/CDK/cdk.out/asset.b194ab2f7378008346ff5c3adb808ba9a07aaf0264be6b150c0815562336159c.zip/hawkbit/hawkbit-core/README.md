# hawkBit Core

Various internal interfaces and utility classes.