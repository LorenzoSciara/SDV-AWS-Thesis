import json
import os
import sys
import base64
from botocore.vendored import requests
from decimal import Decimal
import json
from datetime import datetime, date, timedelta, timezone
import boto3
from botocore.config import Config
import time

def lambda_handler(event, context):
    
    kinesis_messages = get_kinesis_message(event)
    session = boto3.Session()
    write_client = session.client('timestream-write', config=Config(
    read_timeout=20, max_pool_connections=5000, retries={'max_attempts': 10}))
    
    common_attributes = prepare_common_attributes(kinesis_messages[0]['DeviceID'])
    records = {}
    for kinesis_message in kinesis_messages:
        data_ora_dt = datetime.fromisoformat(kinesis_message['Timestamp'])
        current_time = int(data_ora_dt.timestamp()*1000)
        
        
        for table in kinesis_message.keys():
            record = prepare_record(current_time)
            if type(kinesis_message[table]) is dict:
                flatten = flatten_json(kinesis_message[table])
                for column in flatten.keys():
                    record['MeasureValues'].append(prepare_measure(column, flatten[column]))
                if records.get(table) is None:
                    records[table] = []
                records[table].append(record)
                
    for table in records.keys():
        write_records(records[table], common_attributes, write_client, table)
    return 
    

def get_kinesis_message(kinesis_message):
    newKinesisObj = []
    deviceID = ""
    for record in kinesis_message['Records']:
        #Kinesis data is base64 encoded so decode here
        payloadStr=base64.b64decode(record["kinesis"]["data"])
        payload_utf8=str(payloadStr, 'utf-8')
        payload_utf8 = payload_utf8.replace("'", '"')
        payload_utf8 = payload_utf8.lstrip('"').rstrip('"')
        payload = json.loads(payload_utf8, parse_float=Decimal)
        newKinesisObj.append(payload)
    return newKinesisObj

def prepare_common_attributes(common):
  common_attributes = {
    'Dimensions': [
      {'Name': 'DeviceID', 'Value': common}
    ],
    'MeasureName': common,
    'MeasureValueType': 'MULTI'
  }
  return common_attributes


def prepare_record(current_time):
  record = {
    'Time': str(current_time),
    'MeasureValues': []
  }
  return record
  
def write_records(records, common_attributes, write_client, table_name):
    try:
        result = write_client.write_records(DatabaseName="hawkbitDevice",
                                            TableName= table_name,
                                            CommonAttributes=common_attributes,
                                            Records=records)
                
        status = result['ResponseMetadata']['HTTPStatusCode']
        print("Processed %d records. WriteRecords HTTPStatusCode: %s" %
            (len(records), status))
    except write_client.exceptions.RejectedRecordsException as err:
        print("RejectedRecords: ", err)
        for rr in err.response["RejectedRecords"]:
            print("Rejected Index " + str(rr["RecordIndex"]) + ": " + rr["Reason"])
            print("Other records were written successfully. ")
    except Exception as err:
        print("Error:", err)
    
def prepare_measure(measure_name, measure_value):
  measure = {
    'Name': measure_name,
    'Value': str(measure_value),
    'Type': 'VARCHAR'
  }
  return measure
  
def flatten_json(y):
    out = {}
 
    def flatten(x, name=''):
 
        # If the Nested key-value
        # pair is of dict type
        if type(x) is dict:
 
            for a in x:
                flatten(x[a], name + a + '_')
 
        # If the Nested key-value
        # pair is of list type
        elif type(x) is list:
 
            i = 0
 
            for a in x:
                flatten(a, name + str(i) + '_')
                i += 1
        else:
            out[name[:-1]] = x
 
    flatten(y)
    return out
