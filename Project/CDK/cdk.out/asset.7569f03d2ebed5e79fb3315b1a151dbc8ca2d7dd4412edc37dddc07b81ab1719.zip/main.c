#define _POSIX_SOURCE
#include <fcntl.h>
#include <unistd.h>
#undef _POSIX_SOURCE
#include <stdio.h>

int main (){
    printf("TCU update completed!\n");
    return 0;
}
